package main

import (
	"bytes"
	"encoding/gob"
	"io/ioutil"
	"log"
)

func main() {

}

func read(data interface{}, filename string) {
	raw, err := ioutil.ReadFile(filename)
	if err != nil {
		log.Fatal(err.Error())
	}

	buffer := bytes.NewBuffer(raw)
	dec := gob.NewDecoder(buffer)
	err = dec.Decode(data)

	if err != nil {
		log.Fatal(err.Error())
	}
	return
}

func write(data interface{}, filename string) {
	buffer := new(bytes.Buffer)
	encoder := gob.NewEncoder(buffer)
	err := encoder.Encode(data)
	if err != nil {
		log.Fatal(err.Error())
	}

	err = ioutil.WriteFile(filename, buffer.Bytes(), 0600)
	if err != nil {
		log.Fatal(err.Error())
	}
}
